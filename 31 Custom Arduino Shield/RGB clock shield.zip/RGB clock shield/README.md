# Arduino-UNO-R4-Shield-Template
Arduino UNO R4 Shield Template for KiCad 6.<br/>
Based on official Arduino UNO R4 CAD.

## TO DO
- Make better 3D Headers to reflect real measurements.
## Schematic
![image](https://github.com/MStackoverflow/Arduino-UNO-R4-Shield-Template/assets/137069674/5090f007-6038-4332-898c-bb333dbb85ca)

## PCB View
![image](https://github.com/MStackoverflow/Arduino-UNO-R4-Shield-Template/assets/137069674/1f850703-3dd5-4841-a0d5-444bb851edfd)


## 3D View
![image](https://github.com/MStackoverflow/Arduino-UNO-R4-Shield-Template/assets/137069674/62811265-36d5-49d9-b787-7724e3a6344a)

![image](https://github.com/MStackoverflow/Arduino-UNO-R4-Shield-Template/assets/137069674/734cff69-6ebe-470a-a9f9-ffb4985eada7)

![image](https://github.com/MStackoverflow/Arduino-UNO-R4-Shield-Template/assets/137069674/3e3965d1-9c56-4ce8-9fcd-295fe8139e04)

![image](https://github.com/MStackoverflow/Arduino-UNO-R4-Shield-Template/assets/137069674/132ab9c3-0997-49e3-a216-75cf31df4c05)
